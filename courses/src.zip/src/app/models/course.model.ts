export enum wayLearningEnum { frontal = 1, zoom };
export class Course {
    public id?: number;
    public name?: string;
    public categoryId?: number;
    public amountLessons?: number;
    public startDateLearning?: Date;
    public syllabus?: string[];
    public wayLearning?:wayLearningEnum;
    public lecturerId?:number;
    public imagePath?:string;
}