export class User{
    public id?:number;
    public name?:string;
    public address?:string;
    public email?:string;
    public password?:string;
}